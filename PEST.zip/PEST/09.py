m = float(input("Digite a distância em metros: "))
pés = m*3.28084
polegadas = m*39.3701
milhas = m*0.000621371

print(f"{m} metros é igual a:")
print(f"{polegadas:.2f} polegadas")
print(f"{milhas:.6f} milhas")
print(f"{pés:.2f} pés")