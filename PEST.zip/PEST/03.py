horaInicio = 13
alarme = 51
horaDoalarme = horaInicio + alarme
print(horaDoalarme%24)