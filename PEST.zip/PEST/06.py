base = float(input("Digite o valor da base do triângulo: "))
altura = float(input("Digite o valor da altura do triângulo: "))
area = (base * altura) / 2

print(f"A área do triângulo é: {area:.2f}")