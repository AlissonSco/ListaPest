raio = int(5)
volumeEsfera = (4/3) * 3.14 * (raio ** 3)
print(volumeEsfera)