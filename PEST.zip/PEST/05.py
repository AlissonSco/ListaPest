N = int(input("Digite um número N: "))
NN = N * 10 + N
NNN = N * 100 + NN
print(N, NN, NNN)