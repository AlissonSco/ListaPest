precoLivro = 24.95
desconto = 0.4
valorLivroComDesconto = precoLivro - (precoLivro * desconto)
livroValorCopias = 60 * valorLivroComDesconto
precotransporte = 3.00+0.75*(60-1)
print(f'Preço para as 60 cópias = R${precotransporte + livroValorCopias}')
