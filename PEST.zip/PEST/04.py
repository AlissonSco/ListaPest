horaInicio = int(input('Digite a hora atual: '))
alarme = int(input('DIgite a quantidade de horas para o alarme: '))
hora = (horaInicio+alarme)%24
print(f'O alarme despertará as {hora} horas')