x1, y1 = map(float, input("Digite as coordenadas do primeiro ponto (x1, y1): ").split())
x2, y2 = map(float, input("Digite as coordenadas do segundo ponto (x2, y2): ").split())
distancia = ((x2 - x1)**2 + (y2 - y1)**2)**0.5
print(f"A distância entre os pontos ({x1}, {y1}) e ({x2}, {y2}) é: {distancia:.2f}")