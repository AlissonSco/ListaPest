numero = int(input("Digite um número de 4 dígitos: "))
soma = 0

while numero > 0:
    soma = soma + (numero % 10)
    numero = numero // 10

print(f"A soma dos dígitos é {soma}")