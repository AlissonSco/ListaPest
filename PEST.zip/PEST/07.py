x = float(input("Digite o valor de x: "))
y = float(input("Digite o valor de y: "))

resultado = (x + y) * (x + y)

print(f"O resultado de (x + y) * (x + y) é: {resultado}")